let data = [
            {id:0,title:'로봇',content:'초합금혼 액션 피규어',price:537051},
            {id:1,title:'테디베어',content:'자이언트 브라운',price:22537},
            {id:2,title:'바비 인형',content:'자유롭게 움직이는 바비인형',price:26517}
        ];


export default data;